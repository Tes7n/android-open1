Android Open Source Projects [https://codekk.com](https://p.codekk.com/) for more
====================

Welcome to recommend good android open source projects, you can [Commit](https://github.com/Trinea/android-open-project/wiki/Standard-of-adding-and-editing-content "Standard of adding and editing content") directly or tell me at [Colloct Page](https://github.com/Trinea/android-open-project/issues/1). Welcome `Star` and `Fork`  

#### [Android develop and debug efficiency tool - Developer Tools App](https://play.google.com/store/apps/details?id=cn.trinea.android.developertools)

Twitter：[trinea_cn](https://twitter.com/trinea_cn)&nbsp;&nbsp;&nbsp;&nbsp;HomePage: [www.trinea.cn](https://www.trinea.cn/)&nbsp;&nbsp;&nbsp;&nbsp;Email：[trinea.cn@gmail.com](mailto:trinea.cn@gmail.com)&nbsp;&nbsp;&nbsp;&nbsp;QQ：[717763774](http://wpa.qq.com/msgrd?v=3&uin=717763774&site=qq&menu=yes)  
Share：<a href="https://twitter.com/intent/tweet?text=Android Open Source Projects include Personalized Views, Common Util Libs, Excellent projects and so on   %40trinea_cn+https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&pic=" target="_blank" title="Share on twitter" style="width:100%"><img src="http://farm4.staticflickr.com/3764/13104038813_03933d4394_o.png"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&t=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86200%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&pic" target="_blank" title="Share on facebook" style="width:100%"><img src="http://farm4.staticflickr.com/3801/13104038583_b03d5cafac_o.png"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://service.weibo.com/share/share.php?url=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&title=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86200%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&appkey=1657413438&searchPic=true" target="_blank" title="Shared on weibo" style="width:100%"><img src="http://farm8.staticflickr.com/7342/13103239365_e5cd37fbac_o.png" title="Shared on weibo"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&title=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86200%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&desc=&summary=&site=www.trinea.cn" target="_blank" title="Share on qzone" style="width:100%"><img src="http://farm8.staticflickr.com/7418/13103935825_209bd521f0_o.jpg"/></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://share.v.t.qq.com/index.php?c=share&a=index&url=https%3A%2F%2Fgithub.com%2FTrinea%2Fandroid-open-project&title=Android%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%E5%88%86%E7%B1%BB%E6%B1%87%E6%80%BB%EF%BC%8C%E6%B1%87%E9%9B%86200%E5%A4%9A%E4%B8%AA%E5%BC%80%E6%BA%90%E9%A1%B9%E7%9B%AE%EF%BC%8C%E5%8C%85%E6%8B%AC%E4%B8%AA%E6%80%A7%E5%8C%96%E6%8E%A7%E4%BB%B6%E3%80%81%E5%B7%A5%E5%85%B7%E5%BA%93%E3%80%81%E4%BC%98%E7%A7%80%E9%A1%B9%E7%9B%AE%E3%80%81%E5%BC%80%E5%8F%91%E5%8F%8A%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E3%80%81%E4%BC%98%E7%A7%80%E4%B8%AA%E4%BA%BA%E5%92%8C%E5%9B%A2%E4%BD%93%40Trinea+&appkey=801404464" target="_blank" title="Shared on tecent weibo" style="width:100%"><img src="http://farm8.staticflickr.com/7452/13104204564_f867971a13_o.png"/></a>
### Include：  
>[1. Personalized Views](#1-personalized-views )  
*&nbsp;&nbsp;
include [ListView](#1-listview),
[ActionBar](#2-actionbar),
[Menu](#3-menu),
[ViewPager](#4-viewpager-gallery),
[Gallery](#5-gridview),
[ImageView](#6-imageview),
[ProgressBar](#7-progressbar),
[TextView](#8-textview),
ScrollView, 
TimeView, 
TipView, 
FlipView, 
ColorPickView, 
GraphView,
UI Style, 
[Others](#9-others)*  
[2. Common Util Libs](#2-common-util-libs)  
*&nbsp;&nbsp;include [Dependency Injection](#1-dependency-injection),
[ImageCache](#2-image-cache),
[Network](#3-network),
[Database ORM](#4-database),
[Android common lib](#5-android-common-lib),
[Compatible low version](#6-android-compatible-low-version),
[Multimedia](#7-multimedia),
[Event Bus](#8-event-bus),
[Sensor](#9-sensor),
[Security](#10-security),
[Maps](#11-maps),
Plug-in,
File,
[Others](#12-others)*  
[3. Excellent projects](#3-excellent-projects)  
*&nbsp;&nbsp;more interesting android project*  
[4. Development and testing tools](#4-development-and-testing-tools)  
*&nbsp;&nbsp;include [Development productivity tools](https://github.com/Trinea/android-open-project/tree/master/English%20Version#first-development-productivity-tools), [Develop self-test related](https://github.com/Trinea/android-open-project/tree/master/English%20Version#second-develop-self-test-related), [Testing tools](https://github.com/Trinea/android-open-project/tree/master/English%20Version#third-testing-tools), [Development and build environment](https://github.com/Trinea/android-open-project/tree/master/English%20Version#fourth-development-and-build-environment), [Others](https://github.com/Trinea/android-open-project/tree/master/English%20Version#fifth-others)*  
[5. Outstanding individuals and groups](#4-outstanding-individuals-and-groups)  
*&nbsp;&nbsp;Willing to share and have some very good open source project [Individual](https://github.com/Trinea/android-open-project/tree/master/English%20Version#first-individual) and [Group](https://github.com/Trinea/android-open-project/tree/master/English%20Version#second-group)，include JakeWharton, Chris Banes, Koushik Dutta and so on*
  
*Thank [likebamoo](https://github.com/likebamboo)  [vmlinz](https://github.com/vmlinz)  [xalexchen](https://github.com/xalexchen)  [youxiachai](https://github.com/youxiachai) [stormzhang](https://github.com/stormzhang)*  

## 1. Personalized Views  
Customed View. include ListView, ActionBar, Menu, ViewPager, Gallery, GridView, ImageView, ProgressBar, Dialog, Toast, EditText, TableView, Activity Animation and so on。  
#### 1. ListView  
1. android-pulltorefresh  
Provide a reusable Pull to Refresh widget for Android, support ListView, ExpandableListView, GridView, WebView, ScrollView, HorizontalScrollView, ViewPager, support pulling Down from the top, and Pulling Up from the bottom and so on.  
Project Address: https://github.com/chrisbanes/Android-PullToRefresh  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/pull-to-refreshview-demo.apk?raw=true  
Similar App: Sina Weibo Pages  
   
1. android-pulltorefresh-listview  
Pull to refresh listView for android, There is some bug for this  
Project Address: https://github.com/johannilsson/android-pulltorefresh  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/pull-to-refresh-listview-demo.apk?raw=true   

1. android-Ultra-Pull-to-Refresh    
It's a replacement for the deprecated pull to refresh solution. It can contain any view you want.
It's easy to use and more powerful than SwipeRefreshLayout.
It's well designed, you can customize the UI effect you want as easy as adding a headview to ListView.
Support `API LEVEL >= 8`
Project Address: https://github.com/liaohuqiu/android-Ultra-Pull-To-Refresh   
Demo Apk: https://github.com/liaohuqiu/android-Ultra-Pull-To-Refresh/blob/master/ptr-demo/target/ultra-ptr-demo.apk?raw=true  
<div>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/contains-all-of-views.gif' width="150px"/>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/release-to-refresh.gif' width="150px"/>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/auto-refresh.gif' width="150px"/>  
    <img src='http://srain-github.qiniudn.com/ultra-ptr/store-house-string-array.gif' width="150px"/>  
</div>   
   
1. DropDownListView  
Pull to refresh and load more when on bottom listView for android  
Project Address: https://github.com/Trinea/AndroidCommon  
Demo Apk: https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
Document: https://www.trinea.cn/android/dropdown-to-refresh-and-bottom-load-more-listview/  
   
1. DragSortListView  
Android ListView with drag and drop reordering.   
Project Address: https://github.com/bauerca/drag-sort-listview  
Demo Apk: https://play.google.com/store/apps/details?id=com.mobeta.android.demodslv  
Similar App: Wordpress Android  
   
1. SwipeListView  
An Android List View implementation with support for drawable cells and many other swipe related features  
Project Address: https://github.com/47deg/android-swipelistview  
Demo Apk: https://play.google.com/store/apps/details?id=com.fortysevendeg.android.swipelistview  
Similar App: 微信

1. SlideAndDragListView  
An extension of the Android ListView that enables slide and drag-and-drop reordering of list items.  
Project Address: https://github.com/yydcdut/SlideAndDragListView  
Demo Apk: https://github.com/yydcdut/SlideAndDragListView/blob/master/apk/sdlv.apk?raw=true  
Similar App: Android 手机QQ 5.0  
Renderings: ![Renderings](https://raw.githubusercontent.com/yydcdut/SlideAndDragListView/master/gif/v1.1.gif)  

   
1. RecyclerViewSwipeDismiss
lightweight support-v7 RecyclerView Swipe to dismiss library，Just bind `onTouchListener`
Project Address：https://github.com/CodeFalling/RecyclerViewSwipeDismiss
Renderings: ![Renderings](http://i2.tietuku.com/a5a1a6fbd300397a.gif)

1. Android-SwipeToDismiss
Android swipe to dismiss listView  
Project Address: https://github.com/romannurik/Android-SwipeToDismiss  
Demo Apk: https://github.com/JakeWharton/SwipeToDismissNOA/SwipeToDismissNOA.apk/qr_code  
   
1. StickyListHeaders  
An android library for section headers of listView that stick to the top  
Project Address: https://github.com/emilsjolander/StickyListHeaders  
Similar App: Contacts app of Android 4.0 Ice Cream Sandwich  
Renderings: ![Renderings](https://raw.github.com/emilsjolander/StickyListHeaders/master/demo.gif)  
   
1. pinned-section-listview  
Easy to use ListView with pinned sections for Android. Pinned section is a header view which sticks to the top of the list until at least one item of that section is visible.  
Project Address: https://github.com/beworker/pinned-section-listview  
Renderings: ![Renderings](https://raw.github.com/beworker/pinned-section-listview/master/screen1.png)  
   
1. PinnedHeaderListView  
A ListView with pinned section headers for Android  
Project Address: https://github.com/JimiSmith/PinnedHeaderListView  
   
1. QuickReturnHeader  
A ListView/ScrollView header that hides when scrolling down and reappears immediately when scrolling up, regardless of how far down the list we've gone.  
Project Address: https://github.com/ManuelPeinado/QuickReturnHeader  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/quick-return-header-demo.apk?raw=true  
Similar App: google plus  
   
1. IndexableListView  
iPhone like fast scroll ListView on Android with non-alphabetic overlays  
Project Address: https://github.com/woozzu/IndexableListView  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/indexable-listview.apk?raw=true  
Similar App: Weichat contact  
   
1. CustomFastScrollView  
A FastScrollView with non-alphabetic overlays  
Project Address: https://github.com/nolanlawson/CustomFastScrollViewDemo  
Renderings: ![Renderings](https://raw.github.com/nolanlawson/CustomFastScrollViewDemo/master/example.png)  
   
1. Android-ScrollBarPanel  
Android-ScrollBarPanel allows to attach a View to a scroll indicator like it's done in Path 2.0  
Project Address: https://github.com/rno/Android-ScrollBarPanel  
Renderings: ![Renderings](https://github.com/rno/Android-ScrollBarPanel/raw/master/demo_capture.png)  
   
1. SlideExpandableListView  
A better ExpandableListView, with animated expandable views for each list item  
Project Address: https://github.com/tjerkw/Android-SlideExpandableListView  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/slide-expandable-listView-demo.apk?raw=true  
   
1. JazzyListView  
JazzyListView is an extension of ListView designed to animate list item views as they become visible. There are a number of pre-built, bundled effects that can be used by setting the effect in code or an XML layout attribute, like grow, cards, curl, wave, flip, fly. Also, it is possible to use a custom effect by implementing a JazzyEffect.  
Project Address: https://github.com/twotoasters/JazzyListView  
Demo Apk: https://play.google.com/store/apps/details?id=com.twotoasters.jazzylistview.sample  
   
1. ListViewAnimations  
An Android library which allows developers to easily add animations to ListView items  
Project Address: https://github.com/nhaarman/ListViewAnimations  
Demo Apk: https://play.google.com/store/apps/details?id=com.haarman.listviewanimations  
Similar App: Google plus, Google Now, Ultimate, Light Flow Lite, TreinVerkeer, Running Coach, Pearl Jam Lyrics, Calorie Chart, Car Hire, Super BART, DK FlashCards, Counter Plus, Voorlees Verhaaltjes 2.0  
   
1. DevsmartLib-Android  
A Horizontal ListView for Android  
Project Address: https://github.com/dinocore1/DevsmartLib-Android  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/horizontal-listview-demo.apk?raw=true  
   
1. HorizontalVariableListView  
Horizontal list view for Android which allows variable items widths  
Project Address: https://github.com/sephiroth74/HorizontalVariableListView   
   
1. LinearListView  
Android library that allows you to bind a LinearLayout with a ListAdapter.  
Project Address: https://github.com/frankiesardo/LinearListView   
  
1. MultiChoiceAdapter  
A ListView adapter with support for multiple choice modal selection  
Project Address: https://github.com/ManuelPeinado/MultiChoiceAdapter   
Demo Apk: https://play.google.com/store/apps/details?id=com.manuelpeinado.multichoiceadapter.demo  

1. EnhancedListView  
An Android ListView with enhanced functionality (e.g. Swipe To Dismiss and Undo)   
Project Address: https://github.com/timroes/EnhancedListView   
Demo Apk: https://play.google.com/store/apps/details?id=de.timroes.android.listviewdemo&rdid=de.timroes.android.listviewdemo   
   
1. ListBuddies  
Android library of a pair of auto-scroll circular parallax ListViews like the ones on the expedia app home page.   
Project Address: https://github.com/jpardogo/ListBuddies   
Demo Apk: https://play.google.com/store/apps/details?id=com.jpardogo.android.listbuddies   
Renderings: ![Renderings](https://raw.github.com/jpardogo/ListBuddies/master/art/screenshot_listbuddies_2.png)  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>     

1. RecyclerItemDecoration  
RecyclerItemDecoration allows you to draw divider between items in recyclerview with multiple ViewType without considering items' positions!
You don't need to think about items' position! You need to care about their ViewType!!  
Project Address: https://github.com/magiepooh/RecyclerItemDecoration  
Renderings: ![Renderings:](https://raw.githubusercontent.com/magiepooh/RecyclerItemDecoration/master/art/demo_vertical.gif) ![Renderings:](https://raw.githubusercontent.com/magiepooh/RecyclerItemDecoration/master/art/demo_horizontal.gif)

#### 2. ActionBar  
1. ActionBarSherlock  
Action bar implementation which uses the native action bar on Android 4.0+ and a custom implementation on pre-4.0 through a single API and theme.   
Project Address: https://github.com/JakeWharton/ActionBarSherlock  
Demo Apk: https://play.google.com/store/apps/details?id=com.actionbarsherlock.sample.demos  
   
1. ActionBar-PullToRefresh  
ActionBar-PullToRefresh provides an easy way to add a modern version of the pull-to-refresh interaction to your application.  
Project Address: https://github.com/chrisbanes/ActionBar-PullToRefresh  
Demo Apk: https://play.google.com/store/apps/details?id=uk.co.senab.actionbarpulltorefresh.samples.stock  
Similar App: Gmail，Google plus  
   
1. FadingActionBar  
Android library implementing a fading effect for the action bar, similar to the one found in the Play Music app  
Project Address: https://github.com/ManuelPeinado/FadingActionBar  
Demo Apk: https://play.google.com/store/apps/details?id=com.manuelpeinado.fadingactionbar.demo  
Similar App: google music  
   
1. NotBoringActionBar  
Auto dismis actionbar when content scroll down  
Project Address: https://github.com/flavienlaurent/NotBoringActionBar  
Demo Apk: http://flavienlaurent.com/blog/2013/11/20/making-your-action-bar-not-boring/  
Similar App: google music  
   
1. RefreshActionItem  
An action bar item which acts both as a refresh button and as a progress indicator  
Project Address: https://github.com/ManuelPeinado/RefreshActionItem  
Demo Apk: https://play.google.com/store/apps/details?id=com.manuelpeinado.refreshactionitem.demo  
Similar App: The New York Times，DevAppsDirect.  
   
1. GlassActionBar  
An Android library which implements a glass-like effect for the action bar  
Project Address: https://github.com/ManuelPeinado/GlassActionBar  
Demo Apk: https://play.google.com/store/apps/details?id=com.manuelpeinado.glassactionbardemo  
Similar App: google music  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 3. Menu   
1. MenuDrawer   
A slide-out menu implementation, which allows users to navigate between views in your app. Most commonly the menu is revealed by either dragging the edge of the screen, or clicking the 'up' button in the action bar. It support content below or up to menu when compare to SlidingMenu.  
Project Address: https://github.com/SimonVT/android-menudrawer  
Demo Apk: http://simonvt.github.io/android-menudrawer/  
Similar App: Gmail, Google Music  
   
1. SlidingMenu  
An Android library that allows you to easily create applications with slide-in menus. It support animation when compare to MenuDrawer.  
Project Address: https://github.com/jfeinstein10/SlidingMenu  
Demo Apk: https://play.google.com/store/apps/details?id=com.slidingmenu.example  
Similar App: Foursquare, LinkedIn, Zappos, Rdio, Evernote Food, Plume, VLC for Android, ESPN ScoreCenter, MLS MatchDay, 9GAG, Wunderlist 2, The Verge, MTG Familiar, Mantano Reader, Falcon Pro (BETA), MW3 Barracks  
   
1. ArcMenu  
An android custom view which looks like the menu in Path 2.0 for iOS.  
Project Address: https://github.com/daCapricorn/ArcMenu  
Similar App: Path  
Renderings: ![Renderings](https://dl.dropboxusercontent.com/u/11369687/preview0.png)  
   
1. android-satellite-menu  
Android Satellite Menu  
Project Address: https://github.com/siyamed/android-satellite-menu  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/satellite-menu-demo.apk?raw=true  
Similar App: Path  
   
1. radial-menu-widget  
A radial (pie) menu for Android  
Project Address: https://code.google.com/p/radial-menu-widget/  
Renderings: http://farm8.staticflickr.com/7377/11621125154_d1773c2dcc_o.jpg  
   
1. Android Wheel Menu  
Circular menu widget for Android.  
Project Address: https://github.com/anupcowkur/Android-Wheel-Menu  
Renderings: ![Renderings](https://raw.github.com/anupcowkur/Android-Wheel-Menu/master/graphics/wheel.gif)  
   
1. FoldingNavigationDrawer  
Folding navigation drawer for android.  
Project Address: https://github.com/tibi1712/FoldingNavigationDrawer-Android  
Demo Apk: https://play.google.com/store/apps/details?id=com.ptr.folding.sample  
Renderings: ![Renderings](https://lh6.ggpht.com/VnKUZenAozQ0KFAm5blFTGqMaKFjvX-BK2JH-jrX1sIXVTqciACqRhqFH48hc4pm2Q=h310-rw)  

1. AndroidResideMenu  
The idea of ResideMenu is from Dribbble 1 and 2 likes iOS ResideMenu   
Project Address: https://github.com/SpecialCyCi/AndroidResideMenu    
Renderings: ![Renderings](https://github.com/SpecialCyCi/AndroidResideMenu/raw/master/2.gif)    

1. FloatingActionMenu-Animation  
Extended FloatingActionMenu lib, with custom menu icon, animation when scrolling
Project Address: https://github.com/toanvc/FloatingActionMenu-Animation  
Renderings: ![Renderings](https://github.com/toanvc/FloatingActionMenu-Animation/raw/master/screenshots/scale.gif)    
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a> 

#### 4. ViewPager Gallery  
1. Android-ViewPagerIndicator  
Paging indicator widgets compatible with the ViewPager from the Android Support Library and ActionBarSherlock. Originally based on Patrik Åkerfeldt's ViewFlow.   
Project Address: https://github.com/JakeWharton/Android-ViewPagerIndicator  
Demo Apk: https://play.google.com/store/apps/details?id=com.viewpagerindicator.sample  
   
1. JazzyViewPager  
An easy to use ViewPager that adds an awesome set of custom swiping animations. Just change your ViewPagers to JazzyViewPagers and you're good to go!  
Project Address: https://github.com/jfeinstein10/JazzyViewPager  
Demo Apk: https://github.com/jfeinstein10/JazzyViewPager/blob/master/JazzyViewPager.apk?raw=true  

1. Android-DirectionalViewPager  
ViewPager class that supports paging both vertically and horizontally as well as changing between the two at runtime.  
Project Address: https://github.com/JakeWharton/Android-DirectionalViewPager  
Demo Apk: https://market.android.com/details?id=com.directionalviewpager.sample  
   
1. android-pulltorefresh  
Provide a reusable Pull to Refresh widget for Android, support ListView, ExpandableListView, GridView, WebView, ScrollView, HorizontalScrollView, ViewPager, support pulling Down from the top, and Pulling Up from the bottom and so on.    
Project Address: https://github.com/chrisbanes/Android-PullToRefresh  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/pull-to-refreshview-demo.apk?raw=true   
   
1. FancyCoverFlow  
FancyCoverFlow is a flexible Android widget providing out of the box view transformations to give your app a unique look and feel.   
Project Address: https://github.com/davidschreiber/FancyCoverFlow  
Demo Apk: https://play.google.com/store/apps/details?id=at.technikum.mti.fancycoverflow.samples  
Renderings: ![Renderings](https://github-camo.global.ssl.fastly.net/ef5ced52b7b54652b50499521ed797c0188c7a6b/687474703a2f2f64617669647363687265696265722e6769746875622e696f2f46616e6379436f766572466c6f772f73637265656e73686f74322e706e67)  
   
1. AndroidTouchGallery  
Android widget for gallery, using viewpager. Allow pinch zoom and drag for images by url. Widget allows use it in Android > 2.0  
Project Address: https://github.com/Dreddik/AndroidTouchGallery  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/touch-gallery-demo.apk?raw=true    
   
1. Android Auto Scroll ViewPager  
Android Auto scroll ViewPager or ViewPager in ViewPager  
Project Address: https://github.com/Trinea/android-auto-scroll-view-pager  
Demo Apk: https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
Document: https://www.trinea.cn/android/auto-scroll-view-pager/  

1. Salvage view  
Generic view recycler and ViewPager PagerAdapter implementation.  
Project Address: https://github.com/JakeWharton/salvage  
  
1. Android PagerSlidingTabStrip  
An interactive indicator to navigate between the different pages of a ViewPager  
Project Address: https://github.com/astuetz/PagerSlidingTabStrip  
Demo Apk: https://play.google.com/store/apps/details?id=com.astuetz.viewpager.extensions.sample  

1. SmartTabLayout  
A custom ViewPager title strip which gives continuous feedback to the user when scrolling.This library has been added some features and utilities based on android-SlidingTabBasic project of Google Samples.  
Project Address: https://github.com/ogaclejapan/SmartTabLayout  
Demo Apk: https://play.google.com/store/apps/details?id=com.ogaclejapan.smarttablayout.demo  
Renderings: ![Renderings](https://raw.githubusercontent.com/ogaclejapan/SmartTabLayout/master/art/demo1.gif)

1. ViewPager3D    
A ViewPager with 3D effect    
Project Address: https://github.com/inovex/ViewPager3D    

1. AnimaTabsview    
A animation effect like 网易云音乐    
Project Address: https://github.com/wuyexiong/transparent-over-animtabsview   
Demo: http://v.youku.com/v_show/id_XNzA4MjY5NjA0.html    

1. LoopingViewPager
A ViewPager which support loop scroll
Project Address: https://github.com/imbryk/LoopingViewPager

1. android_page_curl
Paging effect of iReader
Project Address: https://github.com/harism/android_page_curl
Demo App:iReader
Demo: https://www.youtube.com/watch?v=iwu7P5PCpsw

1. ViewPagerIndicator
A custom ViewPagerIndicator
Project Address: https://github.com/LuckyJayce/ViewPagerIndicator
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

1. ScreenSlideIndicator
Lightweight ViewPager Cycle Indicadtor
Project Address: [ScreenSlidePager](https://github.com/LyndonChin/Android-ScreenSlidePager)
Renderings: ![](https://raw.githubusercontent.com/LyndonChin/Android-ScreenSlidePager/master/screenslidepager.gif)

1. ViewPager3D
A ViewPager with 3D effect
Project Address: https://github.com/inovex/ViewPager3D

1. AnimaTabsview
A animation effect like 网易云音乐
Project Address: https://github.com/wuyexiong/transparent-over-animtabsview
Demo: http://v.youku.com/v_show/id_XNzA4MjY5NjA0.html

1. LoopingViewPager
A ViewPager which support loop scroll
Project Address: https://github.com/imbryk/LoopingViewPager

1. android_page_curl
Paging effect of iReader
Project Address: https://github.com/harism/android_page_curl
Demo App: iReader
Demo: https://www.youtube.com/watch?v=iwu7P5PCpsw

1. ViewPagerIndicator
A custom ViewPagerIndicator
Project Address: https://github.com/LuckyJayce/ViewPagerIndicator

1. ScreenSlideIndicator
Lightweight ViewPager Cycle Indicadtor
Project Address: [ScreenSlidePager](https://github.com/LyndonChin/Android-ScreenSlidePager)
Renderings: ![](https://raw.githubusercontent.com/LyndonChin/Android-ScreenSlidePager/master/screenslidepager.gif)

1. RecyclerViewPager
A ViewPager implemention inherits from RecyclerView. Support fling operation like gallary and custom fling speed. Support Fragment.
Project Address: [RecyclerViewPager](https://github.com/lsjwzh/RecyclerViewPager)
Renderings:
![](https://github.com/lsjwzh/RecyclerViewPager/blob/master/fragment.gif)
<a href="https://github.com/Trinea/android-open-project#%E7%9B%AE%E5%89%8D%E5%8C%85%E6%8B%AC" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

1. WoWoViewPager
A material design Viewpager.Optimized for scrolling app intros or making your CV app. Free and open source.
WoWoViewPager combines animations and viewpager. When you are swiping viewpager, you are also controlling the frames of the animation. Just like rewinding time.
Project Address: [WoWoViewPager](https://github.com/Nightonke/WoWoViewPager)
Renderings: ![](https://github.com/Nightonke/WoWoViewPager/blob/master/Pictures/AppIntroExample.gif)

#### 5. GridView
1. StaggeredGridView  
A modified version of Android's experimental StaggeredGridView. Includes own OnItemClickListener and OnItemLongClickListener, selector, and fixed position restore. contains cache, extends from ViewGroup  
Project Address: https://github.com/maurycyw/StaggeredGridView  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/staggered-gridview-demo.apk?raw=true  
Similar App: Pinterest  
   
1. AndroidStaggeredGrid  
An Android staggered grid view which supports multiple columns with rows of varying sizes. extends from AbsListView  
Project Address: https://github.com/etsy/AndroidStaggeredGrid  
Similar App: Pinterest  
   
1. PinterestLikeAdapterView  
An Android multi column list view like Pinterest. allow pull to refresh.  
Project Address: https://github.com/GDG-Korea/PinterestLikeAdapterView  
Similar App: Pinterest  
   
1. DraggableGridView  
A drag-and-drop scrolling grid view for Android, extends from ViewGroup. It can  swich from up to bottom, If you want switch from left screen to right please use PagedDragDropGrid below  
Project Address: https://github.com/thquinn/DraggableGridView  
Demo Apk: https://github.com/thquinn/DraggableGridView/blob/master/bin/DraggableGridViewSample.apk?raw=true  
You can customize the width and height of item,and the count of item each line,You can also customize the padding of line.Default value is 20dp.  
Project Address: [DraggableGridView](https://github.com/andyken/DraggableGridView)  
Renderings:   
![Renderings](https://github.com/andyken/DraggableGridView/blob/master/sample/sample.gif)

1. DividedDraggableView
Draggable grid view with divided line.
Project Address: https://github.com/andyken/DividedDraggableView
Renderings:
![Renderings](https://github.com/andyken/DividedDraggableView/blob/master/app/sample.gif)

1. StickyGridHeaders  
StickyGridHeaders is an Android library that provides a GridView that shows items in sections with headers. By default the section headers stick to the top like the People app in Android 4.x but this can be turned off.  
Project Address: https://github.com/TonicArtos/StickyGridHeaders     
Renderings: ![Renderings](https://github-camo.global.ssl.fastly.net/90b57e9383704c400706545225d439e057c6fcc0/687474703a2f2f342e62702e626c6f6773706f742e636f6d2f2d535f4262685758367754592f55517057306377554745492f41414141414141414776552f7a7a4a586a2d50635662592f73313630302f73637265656e2d6c616e6473636170652d736d616c6c65722e706e67)    

1. PagedDragDropGrid  
An Android ViewGroup that implements a paged grid with drag'n'drop moveable items. It can  swich from left screen to right, If you want switch from up to bottom please use DraggableGridView above   
Project Address: https://github.com/mrKlar/PagedDragDropGrid  
Demo视频：http://youtu.be/FYTSRfthSuQ  

1. Android-DraggableGridViewPager  
Zaker style grid view pager, support dragging & rearrange, using as zaker's main screen. 
Project Address: https://github.com/zzhouj/Android-DraggableGridViewPager  
Demo Apk: https://github.com/Trinea/trinea-download/blob/master/draggable-grid-viewpager-demo.apk?raw=true
    
1. GridView with Header and Footer    
Same with `ListView`. It allows you call `addHeaderView()`, `addFooterView` to add views to GridView.    
Project Address：https://github.com/liaohuqiu/android-GridViewWithHeaderAndFooter    
Renderings：![Screen Shot](https://raw.githubusercontent.com/liaohuqiu/android-GridViewWithHeaderAndFooter/master/screen-shot.png)    
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 6. ImageView  
1. PhotoView  
Implementation of ImageView for Android that supports zooming, by various touch gestures, like multi-touch and double-tap. Works perfectly when using used in a scrolling parent (such as ViewPager). Allows the application to be notified when the displayed Matrix has changed. Useful for when you need to update your UI based on the current zoom/scroll position.  
Project Address: https://github.com/chrisbanes/PhotoView  
Demo Apk: https://play.google.com/store/apps/details?id=uk.co.senab.photoview.sample  
Similar App: photup  
   
1. android-gif-drawable  
Views and Drawable for displaying animated GIFs on Android. Bundled GIFLib via JNI is used to render frames. This way should be more efficient than WebView or Movie classes. Animation starts automatically and run only if View with attached GifDrawable is visible.  
Project Address: https://github.com/koral--/android-gif-drawable  
  
1. ImageViewEx  
Extension of Android's ImageView that supports animated GIFs and includes a better density management.  
Project Address: https://github.com/frapontillo/ImageViewEx  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/imageviewex-demo.apk?raw=true  
   
1. RoundedImageView  
A fast ImageView that supports rounded corners and ovals or circles  
Project Address: https://github.com/vinc3m1/RoundedImageView  
Renderings: ![Renderings](https://raw.github.com/makeramen/RoundedImageView/master/screenshot.png)  

1. SelectableRoundedImageView  
ImageView that supports different radiuses on each corner. It also supports oval(and circle) shape and border.  
Project Address: https://github.com/pungrue26/SelectableRoundedImageView  
Demo Apk: https://play.google.com/store/apps/details?id=com.joooonho  
Renderings: ![Renderings](https://camo.githubusercontent.com/25d2e5fb8783b5dd09c00b03091172a79c69350e/687474703a2f2f692e696d6775722e636f6d2f55355653376d322e706e673f31)  

1. ColorArt  
iTunes 11-style color matching code for Android, is a library that uses an image to create a themed image/text display  
Project Address: https://github.com/MichaelEvans/ColorArt  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/color-art-demo.apk?raw=true  
   
1. CircleImageView  
A circular ImageView for Android  
Project Address: https://github.com/hdodenhof/CircleImageView  
Renderings: ![Renderings](https://raw.github.com/hdodenhof/CircleImageView/master/screenshot.png)  
  
1. ImageViewZoom  
Android ImageView widget with zoom and pan capabilities   
Project Address: https://github.com/sephiroth74/ImageViewZoom  
Similar App: https://play.google.com/store/apps/details?id=com.aviary.android.feather  
  
1. KenBurnsView  
Android library that provides an extension to ImageView that creates an immersive experience by animating its drawable using the Ken Burns Effect.   
Project Address: https://github.com/flavioarfaria/KenBurnsView  

1. CustomShapeImageView    
Custom shape ImageView using PorterDuffXfermode with paint shapes and SVGs.    
Project Address: https://github.com/MostafaGazar/CustomShapeImageView     
Renderings: ![Renderings](https://raw.github.com/MostafaGazar/CustomShapeImageView/master/Screenshot_2013-11-05-23-08-12.png)   
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 7. ProgressBar  
1. SmoothProgressBar  
A small Android library allowing you to have a smooth and customizable horizontal indeterminate ProgressBar  
Project Address: https://github.com/castorflex/SmoothProgressBar  
Demo Apk: https://play.google.com/store/apps/details?id=fr.castorflex.android.smoothprogressbar.sample  
   
1. ProgressWheel  
A progress wheel for android, intended for use instead of the standard progress bar.  
Project Address: https://github.com/Todd-Davies/ProgressWheel  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/progress-wheel-demo.apk?raw=true  
   
1. android-square-progressbar  
A progressbar which go's around an image.  
Project Address: https://github.com/mrwonderman/android-square-progressbar  
Demo Apk: https://play.google.com/store/apps/details?id=net.yscs.android.square_progressbar_example  
Similar App: square  
Renderings: ![Renderings](https://googledrive.com/host/0BwESwPCuXtw7eExwSFVLQkR2TTg/newscreen1.png)  
   
1. HoloCircularProgressBar  
HoloCircularProgressBar is a Custom View implementation for Android you might know from the Android Clock App from Android 4.1  
Project Address: https://github.com/passsy/android-HoloCircularProgressBar  
Similar App: Android4.1 Clock App  
Renderings: ![Renderings](https://raw.github.com/passsy/android-HoloCircularProgressBar/master/raw/screenshot1.png)  
  
1. ProgressButton  
A custom progress indicator with a tiny footprint.  
Project Address: https://github.com/f2prateek/progressbutton   
Document: http://f2prateek.com/progressbutton/   
Renderings: ![Renderings](http://f2prateek.com/progressbutton/static/states.png)  

1. GoogleProgressBar  
Android library to display different kind of google related animations for the progressBar.   
Project Address: https://github.com/jpardogo/GoogleProgressBar   
Renderings: ![Renderings](https://raw.githubusercontent.com/jpardogo/GoogleProgressBar/master/art/GoogleProgressBar.gif)  

1. TH-ProgressButton  
Circular progress View button inspired by FFCircularProgressView   
Project Address: https://github.com/torryharris/TH-ProgressButton    
Renderings: ![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot1.png)      ![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot2.png)  	![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot3.png)  	![Renderings](https://raw.github.com/Vyshakh-K/TH-ProgressButton/master/screenshots/progressshot4.png)  

1. NumberProgressBar
ProgressBar with percentage number
Project Address:https://github.com/daimajia/NumberProgressBar
Renderings: ![Renderings](https://camo.githubusercontent.com/0c92568af7ec4e04e2e1503acdd2ca99854ab0b5/687474703a2f2f7777332e73696e61696d672e636e2f6d773639302f36313064633033346a77316566797264386e376937673230637a30326d7135662e676966)

1. CircularProgressDrawable
Circular Progress Drawable
Project Address:https://github.com/Sefford/CircularProgressDrawable
Renderings: ![Renderings](https://raw.githubusercontent.com/Sefford/CircularProgressDrawable/master/overshoot.gif)

1. Android-RoundCornerProgressBar
Android ProgressBar drawing Round Corner
Project Address:https://github.com/akexorcist/Android-RoundCornerProgressBar
Renderings: ![Renderings](https://raw.githubusercontent.com/akexorcist/Android-RoundCornerProgressBar/master/image/screenshot_02.png)

1. circular-progress-button
Button could switch to show circular progress
Project Address:https://github.com/dmytrodanylyk/circular-progress-button
Renderings: ![Renderings](https://raw.githubusercontent.com/dmytrodanylyk/circular-progress-button/master/screenshots/intro.gif)

1. WaveView
A ProgressBar which showing wave look progress
Project Address:https://github.com/john990/WaveView
Demo地址：https://raw.github.com/john990/WaveView/master/screenshot%26apk/demo.unaligned.apk
Renderings: ![Renderings](https://camo.githubusercontent.com/60722e9d4f2d2daa78a8650cb27a32adea82bdd4/68747470733a2f2f7261772e6769746875622e636f6d2f6a6f686e3939302f57617665566965772f6d61737465722f73637265656e73686f7425323661706b2f73637265656e73686f742e676966)

1. MaterialLoadingProgressBar
MaterialLoadingProgressBar provide a styled ProgressBar which looks like SwipeRefreshLayout's loading indicator(support-v4 v21+)
Project Address:https://github.com/lsjwzh/MaterialLoadingProgressBar
Renderings: ![Renderings](https://github.com/lsjwzh/MaterialLoadingProgressBar/raw/master/screen.gif)
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

1. LoadingDrawable
some beautiful android loading drawable, can be combined with any view as the loading view and the progressbar.<br>
Project Address:https://github.com/dinuscxj/LoadingDrawable
Renderings: <br/>
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/AnimalDrawable.gif?width=300)
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/SceneryDrawable.gif?width=300)
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/CircleJumpDrawable.gif?width=300)
![LoadingDrawable](https://raw.githubusercontent.com/dinuscxj/LoadingDrawable/master/Preview/CircleRotateDrawable.gif?width=300)

1. StackedHorizontalProgressBar
Stacked dual progress indicator progressbar

Project Address:https://github.com/nisrulz/stackedhorizontalprogressbar

Renderings: </br>
![Sc1](https://github.com/nisrulz/stackedhorizontalprogressbar/blob/master/img/sc1.png) 

#### 8. TextView  
include TextView and other views extend TextView, like EditText, Button, RadioButton and so on  

1. android-flowtextview  
A TextView for Android which supports text wrapping around other views  
Project Address: https://code.google.com/p/android-flowtextview/  
Renderings: http://i949.photobucket.com/albums/ad332/vostroman1500/1.png  
  
1. Android Form EditText  
Android form edit text is an extension of EditText that brings data validation facilities to the edittext.  
Project Address: https://github.com/vekexasia/android-edittext-validator  
Demo Apk: https://play.google.com/store/apps/details?id=com.andreabaccega.edittextformexample  

1. Emojicon  
A library to show emoji in TextView, EditText (like WhatsApp) for Android  
Project Address: https://github.com/rockerhieu/emojicon  
Document: http://rockerhieu.com/emojicon/    

1. android-circlebutton  
Circle button widget for Android, extend from ImageView actually  
Project Address: https://github.com/markushi/android-circlebutton   
Demo Apk: https://github.com/markushi/android-circlebutton/blob/master/example/example.apk    

1. Segmented Radio Buttons for Android  
Android implementation of iPhone's segmented control  
Project Address: https://github.com/vinc3m1/android-segmentedradiobutton  
Demo Apk: https://github.com/thquinn/DraggableGridView/blob/master/bin/DraggableGridViewSample.apk?raw=true  
Renderings: ![Renderings](https://raw.github.com/vinc3m1/android-segmentedradiobutton/master/screens/segmentedradio.png)  

1. Chips EditText Library  
Chips EditText, Token EditText, Bubble EditText, Spannable EditText and etc.. There are many names of this control. Implement by SpannableStringBuilder actually  
Project Address: https://github.com/kpbird/chips-edittext-library  
Demo Apk: https://github.com/kpbird/chips-edittext-library/tree/master/ChipsEditTextDemo/bin  

1. AutoFitTextView  
A TextView that automatically resizes text to fit perfectly within its bounds.    
Project Address: https://github.com/grantland/android-autofittextview  

1. Shimmer for Android  
An Android TextView with a shimmering effect  
Project Address: https://github.com/RomainPiel/Shimmer-android  

1. Titanic   
Android experiment showing a sinking TextView  
Project Address: https://github.com/RomainPiel/Titanic    
Renderings: ![Renderings](https://github.com/RomainPiel/Titanic/raw/master/titanic.gif)   
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. MoneyTextView  
A TextView used for inputing and adding money  
Project Address: https://github.com/andyken/MoneyTextView  
Renderings:   
![Renderings](https://github.com/andyken/MoneyTextView/blob/master/sample/sample1.gif)  

#### 9. Others  
1. youtube-play-icon   
Material style morphing play-pause icon   
Project Address: https://github.com/alxrm/youtube-play-icon   
Renderings:   
![Renderings](https://raw.githubusercontent.com/alxrm/youtube-play-icon/master/art/play.gif)  

1. achartengine  
AChartEngine is a charting library for Android applications. It currently supports the following chart types: line chart, area chart, scatter chart, time chart, bar chart, pie chart, bubble chart, doughnut chart, range (high-low) bar chart, dial chart / gauge, combined (any combination of line, cubic line, scatter, bar, range bar, bubble) chart, cubic line chart and so on.  
Project Address: https://code.google.com/p/achartengine/  
Official Website: http://www.achartengine.org/  
Renderings: ![Renderings](http://www.achartengine.org/dimages/average_temperature.png)  
http://www.achartengine.org/dimages/sales_line_and_area_chart.png  
http://www.achartengine.org/dimages/temperature_range_chart.png  
http://www.achartengine.org/dimages/combined_chart.png  
http://www.achartengine.org/dimages/budget_chart.png  
Similar App: Wordpress Android，Google Analytics  
   
1. GraphView  
Android Graph Library for creating zoomable and scrollable line and bar graphs.  
Project Address: https://github.com/jjoe64/GraphView  
Demo Project: https://github.com/jjoe64/GraphView-Demos  
Demo Apk: https://play.google.com/store/apps/details?id=com.sothree.umano  
Similar App: Wordpress Android，Google Analytics  
   
1. android-flip  
A component for flip animation on Android, which is similar to the effect in Flipboard iPhone/Android  
Project Address: https://github.com/openaphid/android-flip  
Demo Apk: https://github.com/openaphid/android-flip/blob/master/FlipView/Demo/APK/Aphid-FlipView-Demo.apk?raw=true  
Similar App: flipboard  
   
1. FlipImageView  
Small android lib allowing you to make a flip imageview easily, by extending FlipImageView.  
Project Address: https://github.com/castorflex/FlipImageView  
Demo Apk: https://play.google.com/store/apps/details?id=fr.castorflex.android.flipimageview  
   
1. SwipeBackLayout  
An Android library that help you to build app with swipe back gesture.  
Project Address: https://github.com/Issacw0ng/SwipeBackLayout  
Demo Apk: https://play.google.com/store/apps/details?id=me.imid.swipebacklayout.demo  
Similar App: Zhihu  
   
1. Cards-UI  
A library that allows you to easily mimic Google Play's card layout on Android.  
Project Address: https://github.com/afollestad/Cards-UI  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/cards-ui-demo.apk?raw=true  
   
1. cardslib  
Card Library provides an easy way to display a UI Card in your Android app. You can display single cards, list of cards and grid or staggered grid of Cards.  
Project Address: https://github.com/gabrielemariotti/cardslib  
Demo Apk: https://play.google.com/store/apps/details?id=it.gmariotti.cardslib.demo  
   
1. android-styled-dialogs  
A simple library for styling Android dialogs in the Holo theme. It also removes boilerplate code for displaying simple dialogs.  
Project Address: https://github.com/inmite/android-styled-dialogs  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/styled-dialogs-demo.apk?raw=true  
   
1. Crouton  
Context sensitive notifications for Android, like toast. include style like alert, comfirm, info  and click to dismiss, allow to set time of diaplay and customed view  
Project Address: https://github.com/keyboardsurfer/Crouton  
Demo Apk: http://play.google.com/store/apps/details?id=de.keyboardsurfer.app.demo.crouton  
   
1. supertooltips  
SuperToolTips is an Open Source Android library that allows developers to easily create Tool Tips for views.   
Project Address: https://github.com/nhaarman/supertooltips  
Demo Apk: https://play.google.com/store/apps/details?id=com.haarman.supertooltips  
   
1. Android ViewBadger  
A simple way to "badge" any given Android view at runtime without having to cater for it in layout  
Project Address: https://github.com/jgilfelt/android-viewbadger  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/android-viewbadger.apk?raw=true  
Renderings: https://github-camo.global.ssl.fastly.net/a705a3e88c75ae2394943bd7c56f725697616ea8/687474703a2f2f7777772e6a65666667696c66656c742e636f6d2f766965776261646765722f76622d31612e706e67  
   
1. Android Sliding Up Panel  
This library provides a simple way to add a draggable sliding up panel (popularized by Google Music, Google Maps and Rdio) to your Android application. Umano Team <3 Open Source.  
Project Address: https://github.com/umano/AndroidSlidingUpPanel  
Demo Apk: https://play.google.com/store/apps/details?id=com.sothree.umano  
Similar App: Google Music  
   
1. android-times-square  
Standalone Android widget for picking a single date from a calendar view.  
Project Address: https://github.com/square/android-times-square  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/times-square-demo.apk?raw=true  
   
1. android-calendar-card  
Android calendar view (like card)  
Project Address: https://github.com/kenumir/android-calendar-card  
Demo Apk: https://play.google.com/store/apps/details?id=com.wt.calendarcardsample  
Renderings: ![Renderings](https://raw.github.com/kenumir/android-calendar-card/master/calendar-card-sample/_work/device-2013-10-12-151801.png)  
   
1. ColorPickerView  
A simple yet beautiful color picker component for Android.  
Project Address: https://code.google.com/p/color-picker-view/  
Renderings: ![Renderings](http://oi41.tinypic.com/33c6mm8.jpg)  
   
1. HoloColorPicker  
An Android Holo themed colorpicker  
Project Address: https://github.com/LarsWerkman/HoloColorPicker  
Demo Apk: https://docs.google.com/file/d/0BwclyDTlLrdXRzVnTGJvTlRfU2s/edit  
   
1. AndroidWheel  
Custom wheel widget for android  
Project Address: https://github.com/sephiroth74/AndroidWheel  
Renderings: ![Renderings](http://farm6.staticflickr.com/5532/11621528786_220c040ba5_o.jpg)  
   
1. TableFixHeaders  
Android library that implements a table with fixed headers.  
Project Address: https://github.com/InQBarna/TableFixHeaders  
Demo Apk: http://bit.ly/13buAIq  
   
1. UITableView  
Library and example project on how to use the UITableView component  
Project Address: https://github.com/thiagolocatelli/android-uitableview  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/ui-tableview-demo.apk?raw=true  
   
1. ATableView  
Create iOS-like tables (UITableView) for Android, using UIKit object model  
Project Address: https://github.com/dmacosta/ATableView  
Demo Apk: https://play.google.com/store/apps/details?id=com.nakardo.atableview.demo  
   
1. UndoBar  
The UI component for Android advanced UI pattern undo-bar, used in Gmail app  
Project Address: https://github.com/soarcn/UndoBar  
Renderings: ![Renderings](https://github.com/soarcn/UndoBar/blob/master/art/redo.png?raw=true)  
   
1. Inscription  
Inscription is an open source library to display information about your Android app, like info of change or new feature  
Project Address: https://github.com/MartinvanZ/Inscription  
   
1. ActivityTransition  
An android project presenting some transitions you can use between activities, like fade, flip, fly into and so on  
Project Address: https://github.com/ophilbert/ActivityTransition  
Demo Apk： https://github.com/jfeinstein10/JazzyViewPager/blob/master/JazzyViewPager.apk?raw=true    
   
1. GlowPadBackport  
A backport of the Android 4.2 GlowPadView that works on the SDK on API levels 4+  
Project Address: https://github.com/rock3r/GlowPadBackport  
Demo Apk: https://play.google.com/store/apps/details?id=net.sebastianopoggi.samples.ui.GlowPadSample  
Renderings: ![Renderings](https://lh6.ggpht.com/U070b6Lh6cVsVwx4jN-5nq0xqiB1PBzrYABPeJIEe2hZQ5UWOxc-FDUG77wADelToHA=h310-rw)  

1. GlowPadView  
GlowPadView for Android is a great library to implement Googles lockscreen and new alarmclock style.  
Project Address: https://github.com/nadavfima/GlowPadView  
Renderings: https://raw.github.com/nadavfima/GlowPadView/master/example.png  
   
1. android-lockpattern  
Lockpattern activity for Android  
Project Address: https://code.google.com/p/android-lockpattern/  
Demo Apk: https://play.google.com/store/apps/details?id=group.pals.android.lib.ui.lockpattern.demo  
Document: https://code.google.com/p/android-lockpattern/wiki/QuickUse  
  
1. PatternLock  
Yet another pattern lock library for Android  
Project Address：https://github.com/DreaminginCodeZH/PatternLock  
Demo Apk：https://github.com/DreaminginCodeZH/PatternLock/raw/master/dist/sample.apk  
Renderings：![Renderings](https://github.com/DreaminginCodeZH/PatternLock/raw/master/image/sample_small.png)  
   
1. RangeBar  
Android widget for selecting a range of values. It provides for the selection of a range of values rather than a single value.  
Project Address: https://github.com/edmodo/range-bar  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/range-bar-demo.apk?raw=true  
Renderings: ![Renderings](http://i.imgur.com/q85GhRjl.png)  
  
1. SuperToasts  
The SuperToasts library enhances and builds upon the Android Toast class. Some of the features of this library include context sensitive toasts (SuperActivityToasts), toasts with buttons and icons, non context sensitive toasts (SuperToasts), and a new style of toasts (SuperCardToasts) with many customization options for each.  
Project Address: https://github.com/JohnPersano/SuperToasts  
Demo Apk: https://play.google.com/store/apps/details?id=com.supertoastsdemo  
Renderings: ![SuperButtonToast](http://i1331.photobucket.com/albums/w597/JohnPersano/supertoasts_githubimage_zps8a5ceb7c.png)  

1. GoogleDateTimePickers  
New Google Date and time pickers  
Project Address: https://github.com/Mirkoddd/GoogleDateTimePickers  
Document: https://play.google.com/store/apps/details?id=com.mirko.sample&hl=it  
   
1. UndoBar  
An implementation of Android's Undo Bar as seen in Google's Gmail app.  
Project Address: https://github.com/jenzz/Android-UndoBar  
Renderings: ![Renderings](https://raw.github.com/jenzz/Android-UndoBar/master/assets/Screenshot2.png)  
   
1. ColorPickerPreference  
ColorPickerPreference for android to create color picker in preferences.  
Project Address: https://github.com/attenzione/android-ColorPickerPreference  
Renderings: ![Renderings](https://github.com/attenzione/android-ColorPickerPreference/raw/master/screen_2.png)  

1. HoloGraphLibrary  
This is a library written to allow beautiful graphs and charts to be easily incorporated into your Android application.  
Project Address: https://bitbucket.org/danielnadeau/holographlibrary/src  
Document: https://bitbucket.org/danielnadeau/holographlibrary/wiki/Home  

1. ChromeView  
Android WebView implementation that uses the latest Chromium code  
Project Address: https://github.com/pwnall/chromeview  
   
1. Discrollview  
DiscrollView support Item fading in or out, translate or scale  
Project Address: https://github.com/flavienlaurent/discrollview   
Demo Apk: https://github.com/flavienlaurent/discrollview/raw/master/sample.apk    
   
1. Android Slider Preference Library  
Android library that allows applications to add dialog-based slider widgets to their settings  
Project Address: https://github.com/jayschwa/AndroidSliderPreference   

1. ShowcaseView library  
Highlight the best bits of your app to users quickly  
Project Address: https://github.com/amlcurran/ShowcaseView   

1. android-segmented-control  
ios7 UISegmentedControl for android  
Project Address: https://github.com/hoang8f/android-segmented-control   

1. PullScrollView   
Pull and background rebound effect  
Project Address: https://github.com/MarkMjw/PullScrollView    
Renderings: ![Renderings](https://raw.github.com/MarkMjw/PullScrollView/master/Screenshots/1.png)  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. ArcLayout  
A very simple arc layout library  
Project Address: https://github.com/ogaclejapan/ArcLayout  
Demo Apk: https://play.google.com/store/apps/details?id=com.ogaclejapan.arclayout.demo  
Renderings: ![Renderings](https://raw.githubusercontent.com/ogaclejapan/ArcLayout/master/art/demo1.gif)

1. FinestWebView  
Beautiful and customizable Android Activity that shows web pages within an app.  
Project Address: https://github.com/TheFinestArtist/FinestWebView-Android  
Sample App: https://play.google.com/store/apps/details?id=com.thefinestartist.finestwebview.sample  
Renderings: ![Renderings](https://github.com/TheFinestArtist/FinestWebView-Android/blob/master/art/screenshots.png?raw=true)

1. YouTubePlayerActivity  
Simply pass a url to play youtube video in new activity. It supports screen orientation, media volume control and etc.  
Project Address: https://github.com/TheFinestArtist/YouTubePlayerActivity  
Sample App: https://play.google.com/store/apps/details?id=com.thefinestartist.ytpa.sample  
Renderings: ![Renderings](https://github.com/thefinestartist/YouTubePlayerActivity/blob/master/art/preview.gif)

1. TristateToggleButton
Customizable tri-state toggle button (with three states, three state toggle) for Android
Project Address: https://github.com/BeppiMenozzi/TriStateToggleButton  

1. Knob
Fully customizable rotating knob selector with discrete values for Android. Replaces radio buttons, integer value inputs and ViewPager indicators.
Project Address: https://github.com/BeppiMenozzi/Knob

1. Spotlight  
Android Library that lights items for tutorials or walk-throughs etc...
Project Address: https://github.com/TakuSemba/Spotlight   
Renderings:   
![Renderings](https://raw.githubusercontent.com/takusemba/spotlight/master/arts/customTarget.gif)  

1. SpeedView  
Dynamic Speedometer and Gauge for Android. amazing, powerful, and multi shape :zap:
Project Address: https://github.com/anastr/SpeedView   
Renderings:   
![Renderings](https://raw.githubusercontent.com/anastr/SpeedView/master/images/AwesomeSpeedometer.gif)  


## 2. Common Util Libs  
Include Dependency Injection, ImageCache, Network, Database ORM, Android common lib, Compatible low version, Multimedia, Event Bus, Sensor, Security, Plug-in, File, Others<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
#### 1. Dependency Injection  
Speeds up Android development by dependency injection  

1. AndroidAnnotations(Code Diet)  
AndroidAnnotations is an Open Source framework that speeds up Android development. It takes care of the plumbing, and lets you concentrate on what's really important.  
Project Address: https://github.com/excilys/androidannotations  
Document: https://github.com/excilys/androidannotations/wiki  
Official Website: http://androidannotations.org/  
   
1. roboguice  
RoboGuice 2 takes the guesswork out of development. Inject your View, Resource, System Service, or any other object, and let RoboGuice 2 take care of the details.  
Project Address: https://github.com/roboguice/roboguice  
Document: https://github.com/roboguice/roboguice/wiki  
   
1. butterknife  
View "injection" library for Android.  
Project Address: https://github.com/JakeWharton/butterknife  
Document: http://jakewharton.github.io/butterknife/  
   
1. Dagger  
A fast dependency injector for Android and Java.    
Project Address: https://github.com/square/dagger  
Document: http://square.github.io/dagger/  

1. Anvil
A small library for building reactive UI components, data binding and event listener injection. Inspired by React.    
Project Address: https://github.com/zserge/anvil  
Document: http://anvil.site/  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 2. Image Cache  
1. Android-Universal-Image-Loader  
Powerful and flexible library for loading, caching and displaying images on Android.  
Project Address: https://github.com/nostra13/Android-Universal-Image-Loader  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/universal-imageloader-demo.apk?raw=true  
Document: http://www.intexsoft.com/blog/item/74-universal-image-loader-part-3.html  
   
1. picasso  
A powerful image downloading and caching library for Android  
Project Address: https://github.com/square/picasso  
Document: http://square.github.io/picasso/  
   
1. ImageCache  
Image Cache, support multi caching algorithms  
Project Address: https://github.com/Trinea/AndroidCommon  
Demo Apk: https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
Document: https://www.trinea.cn/android/android-imagecache/ 

1. Cube ImageLoader  
Easy to use, high performance, used in some of the Apps in Alibaba Group.
Project Address：https://github.com/etao-open-source/cube-sdk  
Demo Apk：https://github.com/liaohuqiu/cube-sdk/raw/master/cube-sdk-sample.apk  
Document：http://cube-sdk.liaohuqiu.net/  
Renderings: ![Screen Shot](https://raw.githubusercontent.com/etao-open-source/cube-sdk/dev/screen-shot.png)
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 3. Network  
1. Retrofit  
Type-safe REST client for Android and Java by Square  
Project Address: https://github.com/square/retrofit  
Document: http://square.github.io/retrofit/  

1. okhttp  
An HTTP+SPDY client for Android and Java applications.  
Project Address: https://github.com/square/okhttp  
Document: http://square.github.io/okhttp/  

1. Asynchronous Http Client for Android  
An asynchronous, callback-based Http client for Android built on top of Apache's HttpClient libraries.  
Project Address: https://github.com/loopj/android-async-http  
Document: http://loopj.com/android-async-http/  
   
1. android-query  
Android-Query (AQuery) is a light-weight library for doing asynchronous tasks and manipulating UI elements in Android.   
Project Address: https://code.google.com/p/android-query/  
Document: https://code.google.com/p/android-query/#Why_AQuery?  
Demo Apk: https://play.google.com/store/apps/details?id=com.androidquery   
   
1. Async Http Client  
Asynchronous Http and WebSocket Client library for Java  
Project Address: https://github.com/AsyncHttpClient/async-http-client  
Document: http://sonatype.github.io/async-http-client/  
   
1. Ion  
Android Asynchronous Networking and Image Loading  
Project Address: https://github.com/koush/ion  
Document: https://github.com/koush/ion#more-examples  

1. Android Networking  
Android Networking is a powerful library for doing any type of networking in Android Applications 
Project Address: https://github.com/amitshekhariitbhu/AndroidNetworking  
Document: http://amitshekhariitbhu.github.io/AndroidNetworking/  
   
1. Http Request  
A simple convenience library for using a HttpURLConnection to make requests and access the response.  
Project Address: https://github.com/kevinsawicki/http-request  
Document: https://github.com/kevinsawicki/http-request#examples  
   
1. RoboSpice  
RoboSpice is a modular android library that makes writing asynchronous network requests easy  
Project Address: https://github.com/stephanenicolas/robospice  
Demo Apk: https://github.com/stephanenicolas/RoboDemo/downloads  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 4. Database  
1. greenDAO  
GreenDAO is a light & fast ORM solution for Android that maps objects to SQLite databases. Being highly optimized for Android, greenDAO offers great performance and consumes minimal memory.  
Project Address: https://github.com/greenrobot/greenDAO  
Document: http://greendao-orm.com/documentation/  
Official Website: http://greendao-orm.com/  
   
1. ActiveAndroid  
Active record style SQLite persistence for Android  
Project Address: https://github.com/pardom/ActiveAndroid  
Document: https://github.com/pardom/ActiveAndroid/wiki/_pages  
   
1. Sprinkles  
Sprinkles is a boiler-plate-reduction-library for dealing with databases in android applications  
Project Address: https://github.com/emilsjolander/sprinkles  
Document: http://emilsjolander.github.io/blog/2013/12/18/android-with-sprinkles/   
   
1. ormlite-android  
ORMLite Android functionality used in conjunction with ormlite-core  
Project Address: https://github.com/j256/ormlite-android  
Document: http://ormlite.com/sqlite_java_android_orm.shtml   
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 5. Android common lib   
1. Guava  
The Guava project contains several of Google's core libraries that we rely on in our Java-based projects: collections, caching, primitives support, concurrency libraries, common annotations, string processing, I/O, and so forth.  
Project Address: https://code.google.com/p/guava-libraries/  
Document: https://code.google.com/p/guava-libraries/wiki/GuavaExplained  
   
1. Volley  
Easy, Fast Networking for Android  
Project Address: https://android.googlesource.com/platform/frameworks/volley  
Github Address: https://github.com/mcxiaoke/android-volley    
Document: http://commondatastorage.googleapis.com/io-2013/presentations/110%20-%20Volley-%20Easy,%20Fast%20Networking%20for%20Android.pdf  

1. AndroidCommon  
Android common lib, include ImageCache, HttpCache, DropDownListView, DownloadManager, Utils and so on  
Project Address: https://github.com/Trinea/AndroidCommon  
Demo Apk: https://play.google.com/store/apps/details?id=cn.trinea.android.demo  
Document: https://www.trinea.cn/android/android-common-lib/  
   
1. shipfaster  
Sample project demonstrating usage of Dagger + Otto + Robolectric + Retrofit + Picasso + OkHttp  
Project Address: https://github.com/pyricau/shipfaster  
   
1. CleanAndroidCode  
This project is a proof of concept to show how to integrate Dagger, Otto and AndroidAnnotations.  
Project Address: https://github.com/pyricau/CleanAndroidCode  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 6. Android Compatible low version  
1. ActionBarSherlock  
Action bar implementation which uses the native action bar on Android 4.0+ and a custom implementation on pre-4.0 through a single API and theme.  
Project Address: https://github.com/JakeWharton/ActionBarSherlock  
Demo Apk: https://play.google.com/store/apps/details?id=com.actionbarsherlock.sample.demos  
   
1. Nine Old Androids  
Android library for using the Honeycomb animation API on all versions of the platform back to 1.0!  
Project Address: https://github.com/JakeWharton/NineOldAndroids  
Demo Apk: https://play.google.com/store/apps/details?id=com.jakewharton.nineoldandroids.sample  
Document: http://nineoldandroids.com/  
   
1. HoloEverywhere  
Bringing Holo Theme from Android 4.1 to 2.1 and above.  
Project Address: https://github.com/Prototik/HoloEverywhere  
Demo Apk: https://raw.github.com/Prototik/HoloEverywhere/repo/org/holoeverywhere/demo/2.1.0/demo-2.1.0.apk  
Document: http://android-developers.blogspot.com/2012/01/holo-everywhere.html  
   
1. SherlockNavigationDrawer  
Modification of the Android NavigationDrawer sample to use ActionbarSherlock so that we can use the NavigationDrawer on older devices  
Project Address: https://github.com/tobykurien/SherlockNavigationDrawer  

1. Notifications4EveryWhere  
Bringing Notifications from Android 4.1 to 2.2 and above.  
Project Address: https://github.com/youxiachai/Notifications4EveryWhere  
NavigationDrawerDocument: http://developer.android.com/training/implementing-navigation/nav-drawer.html  

1. Android Switch Widget Backport  
A backport of the Switch widget that was introduced on Android 4.X to Android2.1++  
Project Address: https://github.com/BoD/android-switch-backport  
Demo Apk: https://play.google.com/store/apps/details?id=org.jraf.android.backport.switchwidget.sample  
Document: https://github.com/BoD/android-switch-backport#using-the-switch  

1. android-datepicker  
Android 4.0 DatePicker backported to 2.2  
Project Address: https://github.com/SimonVT/android-datepicker  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 7. Multimedia  
1. cocos2d-x  
cocos2d-x is a multi-platform framework for building 2d games, interactive books, demos and other graphical applications. It is based on cocos2d-iphone, but instead of using Objective-C, it uses C++. It works on iOS, Android, Windows Phone, OS X, Windows and Linux.  
Project Address: https://github.com/cocos2d/cocos2d-x  
Document: http://www.cocos2d-x.org/wiki  
Official Website: http://www.cocos2d-x.org/  
   
1. Vitamio  
Vitamio is an open multimedia framework for Android and iOS, with full and real hardware accelerated decoder and renderer.  
Project Address: https://github.com/yixia/VitamioBundle  
Document: http://www.vitamio.org/docs/    
   
1. PhotoProcessing  
A demo of how you can process photos leveraging the ndk, support Instafix, Ansel, Testino, XPro, Retro, BW, Sepia, Cyano, Georgia, Sahara, HDR, Rotate, Flip and so on  
Project Address: https://github.com/lightbox/PhotoProcessing  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/photo-processing.apk?raw=true  
   
1. Android StackBlur  
Android StackBlur is a library that can perform a blurry effect on a Bitmap based on a gradient or radius, and return the result.  
Project Address: https://github.com/kikoso/android-stackblur  
Demo Apk: https://github.com/kikoso/android-stackblur/blob/master/StackBlurDemo/bin/StackBlurDemo.apk?raw=true  
Document: https://github.com/kikoso/android-stackblur#usage  

1. Bitmap Smart Clipping using OpenCV  
Bitmap Smart Clipping using OpenCV  
Project Address: https://github.com/beartung/tclip-android  
   
1. Cropper  
Android widget for cropping and rotating an image.  
Project Address: https://github.com/edmodo/cropper  
Document: https://github.com/edmodo/cropper/wiki  
Renderings: ![Renderings](https://github-camo.global.ssl.fastly.net/e4fde77bf41d4a60b234b4e268e5cfa8c17d9b6f/687474703a2f2f692e696d6775722e636f6d2f334668735467666c2e6a7067)  

1. android-crop  
Android library project for cropping images  
Project Address: https://github.com/jdamcd/android-crop  
Renderings: ![Renderings](https://github.com/jdamcd/android-crop/raw/master/screenshot.png)  

1. TileView  
The TileView widget is a subclass of ViewGroup that provides a mechanism to asynchronously display tile-based images, with additional functionality for 2D dragging, flinging, pinch or double-tap to zoom, adding overlaying Views (markers), built-in Hot Spot support, dynamic path drawing, multiple levels of detail, and support for any relative positioning or coordinate system.  
Project Address: https://github.com/moagrius/TileView  
Demo Apk: http://moagrius.github.io/TileView/TileViewDemo.apk  

1. BlurEffectForAndroidDesign  
Sample to show how to implement blur graphical tricks  
Project Address: https://github.com/PomepuyN/BlurEffectForAndroidDesign  

1. android-eye  
Change your android phone to surveillance camera  
Project Address: https://github.com/Teaonly/android-eye  
Demo Apk: https://play.google.com/store/apps/details?id=teaonly.droideye  

1. libpng for Android  
libpng for Android NDK  
Project Address: https://github.com/julienr/libpng-android  
Document: http://www.libpng.org/pub/png/libpng.html  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

1. Image File Selector  
Project Address: https://github.com/sw926/ImageFileSelector 

#### 8. Event Bus  
A typical use case for Android apps is gluing Activities, Fragments, and background threads together. Conventional wiring of those elements often introduces complex and error-prone dependencies and life cycle issues.   

1. EventBus  
Android optimized event bus that simplifies communication between Activities, Fragments, Threads, Services, etc. Less code, better quality.  
Project Address: https://github.com/greenrobot/EventBus  
Document: https://github.com/greenrobot/EventBus#general-usage-and-api  

1. Otto  
An enhanced Guava-based event bus with emphasis on Android support.  
Project Address: https://github.com/square/otto  
Document: http://square.github.io/otto/  
Demo Apk: https://play.google.com/store/apps/details?id=de.greenrobot.eventperf  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
  
#### 9. Sensor  
1. Great Android Sensing Toolkit  
GAST is a toolkit for using Android's Sensing capabilities. It contains the examples, boiler plate code, and algorithms you need to properly use Android sensors.  
Project Address: https://github.com/gast-lib/gast-lib  
Demo Apk: https://play.google.com/store/apps/details?id=root.gast.playground  
Document: https://github.com/gast-lib/gast-lib#documentation  

1. SensorManager  
Android Sensor Manager Library  
Project Address: https://github.com/nlathia/SensorManager  
Document: https://docs.google.com/document/d/1TqThJULb-4e6TGb1gdkAaPCfyuXStjJpbnt7a0OZ9OE/edit  

1. GPSLogger  
GPSLogger is an Android app that logs GPS information to GPX, KML or text files and has options for annotating and sharing.  
Project Address: https://github.com/mendhak/gpslogger  
Demo Apk: https://play.google.com/store/apps/details?id=com.mendhak.gpslogger  
Document: http://code.mendhak.com/gpslogger/  

1. Pedometer  
Lightweight pedometer app for Android using the hardware step sensor  
Project Address: https://github.com/j4velin/Pedometer  

1. leapcast  
ChromeCast emulation app for any device  
Project Address: https://github.com/dz0ny/leapcast  

1. Arduino-Communicator  
Very simple Android application for communicating with Arduino  
Project Address: https://github.com/jeppsson/Arduino-Communicator  

1. android-pedometer  
App for Android phones that counts your steps.  
Project Address: https://github.com/bagilevi/android-pedometer  
Demo Apk: http://pedometer.googlecode.com/files/Pedometer-1.4.apk  

1. OwnTracks for Android  
OwnTracks Android App  
Project Address: https://github.com/owntracks/android  

1. Shake Detector library for Android   
This library provides a easy way to detect a shake movement using the build-in accelerometer and fire a callback on the UI thread every times it happens.  
Project Address: https://github.com/tbouron/ShakeDetector  
Demo Apk: https://play.google.com/store/apps/details?id=com.github.tbouron.shakedetector.example  

1. Android heart rate monitor   
Android heart rate monitor  
Project Address: https://github.com/phishman3579/android-heart-rate-monitor  

1. Bluetooth LE Library for Android   
This library allows for easy access to a Bluetooth LE device's AdRecord and RSSI value. It offers additional functionality for iBeacons.  
Project Address: https://github.com/alt236/Bluetooth-LE-Library---Android  
Demo Apk: https://play.google.com/store/apps/details?id=uk.co.alt236.btlescan  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. Sensey   
Android library which makes detecting gestures a breeze.  
Project Address: https://github.com/nisrulz/sensey

#### 10. Security  
1. SQLCipher  
SQLCipher is an SQLite extension that provides 256 bit AES encryption of database files.  
Project Address: https://github.com/sqlcipher/sqlcipher  
Document: http://sqlcipher.net/sqlcipher-for-android/  

1. Conceal  
Conceal provides easy Android APIs for performing fast encryption and authentication of data, such as that stored on SD cards  
Project Address: https://github.com/facebook/conceal  
Document: https://github.com/facebook/conceal#usage  

1. Android-PasscodeLock  
Android Library that provides passcode lock to your app  
Project Address: https://github.com/wordpress-mobile/Android-PasscodeLock  
Demo Apk: https://play.google.com/store/apps/details?id=com.sothree.umano  
Similar App: Wordpress Android, Alipay  

1. GlowPadBackport  
A backport of the Android 4.2 GlowPadView that works on the SDK on API levels 4+  
Project Address: https://github.com/rock3r/GlowPadBackport  
Demo Apk: https://play.google.com/store/apps/details?id=net.sebastianopoggi.samples.ui.GlowPadSample  
Renderings: ![Renderings](https://lh6.ggpht.com/U070b6Lh6cVsVwx4jN-5nq0xqiB1PBzrYABPeJIEe2hZQ5UWOxc-FDUG77wADelToHA=h310-rw)  

1. GlowPadView  
GlowPadView for Android is a great library to implement Google's lockscreen and new alarmclock style. (Taken from Android's Source Code)  
Project Address: https://github.com/nadavfima/GlowPadView  
Renderings: https://raw.github.com/nadavfima/GlowPadView/master/example.png  
   
1. android-lockpattern  
lockpattern activity for Android  
Project Address: https://code.google.com/p/android-lockpattern/  
Demo Apk: https://play.google.com/store/apps/details?id=group.pals.android.lib.ui.lockpattern.demo  
Document: https://code.google.com/p/android-lockpattern/wiki/QuickUse  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 11. Maps
1. GraphHopper
Fast routing library and server using OpenStreetMap  
Project Address: https://github.com/graphhopper/graphhopper/  
Document: https://github.com/graphhopper/graphhopper/blob/master/docs/index.md#developers  
Example APK address: https://graphhopper.com/#community  
Official Website: https://graphhopper.com  
Similar App: https://github.com/graphhopper/graphhopper/blob/master/docs/android/index.md#cruiser-app  
Online Demo: https://graphhopper.com/maps  

2. Mapsforge
Software for maps rendering based on OpenStreetMap  
Project Address: https://github.com/mapsforge/mapsforge/  
Document: https://github.com/mapsforge/mapsforge/blob/master/docs/Getting-Started-Developers.md  
Example APK address: https://graphhopper.com/#community  
Renderings: ![Renderings](https://raw.githubusercontent.com/mapsforge/mapsforge/master/docs/images/screenshot-berlin-1.png)
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

#### 12. Others  
1. Salvage view  
Generic view recycler and ViewPager PagerAdapter implementation.  
Project Address: https://github.com/JakeWharton/salvage  
   
1. Android Priority Job Queue  
A Job Queue specifically written for Android to easily schedule jobs (tasks) that run in the background, improving UX and application stability.  
Project Address: https://github.com/path/android-priority-jobqueue  
Document: https://github.com/path/android-priority-jobqueue#getting-started  

1. Glide Bitmap Pool  
Glide Bitmap Pool is a memory management library for reusing the bitmap memory
Project Address: https://github.com/amitshekhariitbhu/GlideBitmapPool 
Document: https://amitshekhariitbhu.github.io/GlideBitmapPool/ 

1. jsoup  
Java HTML Parser, with best of DOM, CSS, and jquery  
Project Address: https://github.com/jhy/jsoup  
Official Website: http://jsoup.org/  
   
1. ZIP  
ZeroTurnaround ZIP Library  
Project Address: https://github.com/zeroturnaround/zt-zip  
Document: https://github.com/zeroturnaround/zt-zip#examples  
   
1. Cobub Razor  
Cobub Razor - Open Source Mobile Analytics Solution, include web, android，ios, window phone  
Project Address: https://github.com/cobub/razor  
Demo Apk: http://demo.cobub.com/razor  
Document: http://dev.cobub.com/  
   
1. aFileChooser  
Android library that provides a file explorer to let users select files on external storage.  
Project Address: https://github.com/iPaulPro/aFileChooser  
   
1. androidpn  
An open source project to provide push notification support for Android -- a xmpp based notification server and a client tool kit.  
Project Address: https://github.com/dannytiehui/androidpn  
 
1. purePDF  
A complete actionscript PDF library  
Project Address: https://github.com/sephiroth74/purePDF  

1. Bolts  
Bolts is a collection of low-level libraries designed to make developing mobile apps easier.  
Project Address: https://github.com/BoltsFramework/Bolts-Android/  

1. CastCompanionLibrary-android  
CastCompanionLibrary-android is a library project to enable developers integrate Cast capabilities into their applications faster and easier.  
Project Address: https://github.com/googlecast/CastCompanionLibrary-android  
Document: https://developers.google.com/cast/  
  
1. CastVideos-android  
CastVideos-android application shows how to cast videos from an android device in a way that is fully compliant with the Design Checklist.  
Project Address: https://github.com/googlecast/CastVideos-android  
Document: https://developers.google.com/cast/  
  
1. Uninstall_Statics  
Android Statistical application is uninstalled  
Project Address: https://github.com/sevenler/Uninstall_Statics  
Document: http://www.cnblogs.com/zealotrouge/p/3157126.html  

1. xCombine  
Android Plugin Framework  
Project Address: https://github.com/wyouflf/xCombine  
Document: http://my.oschina.net/u/1171837/blog/155377  

1. Memento  
Memento is an annotation processor for Android that gives your activities a memory. It introduces the @Retain annotation, which allows you to retain arbitrary fields of an activity across configuration changes in a simple and type-safe manner.  
Project Address: https://github.com/mttkay/memento  
Document: https://github.com/mttkay/memento#usage  

1. svg-android  
SVG parsing and rendering for Android  
Project Address: https://code.google.com/p/svg-android/  

1. Office 365 SDK for Android Preview  
Office 365 SDK for Android Preview by Microsoft Open Technologies, Inc. support Microsoft SharePoint Lists, Microsoft SharePoint Files, Microsoft Exchange Calendar, Microsoft Exchange Contacts, Microsoft Exchange Mail  
Project Address: https://github.com/OfficeDev/Office-365-SDK-for-Android  

1. OpenSpritz-Android  
OpenSpritz concept for Android, is a Spritz-like .epub and website reader for Android 3.0+   
Project Address: https://github.com/OnlyInAmerica/OpenSpritz-Android  
   
1. FreeFlow  
A layout engine for Android that decouples layouts from the View containers that manage scrolling and view recycling. FreeFlow makes it really easy to create custom layouts and beautiful transition animations as data and layouts change  
Project Address: https://github.com/Comcast/FreeFlow  
Demo Apk: https://github.com/Comcast/FreeFlow/releases  

1. Android Gesture Detectors Framework  
Gesture detector framework for multitouch handling on Android  
Project Address: https://github.com/Almeros/android-gesture-detectors  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

1. CacheUtilsLibrary  
This is a simple Android utils library to write any type of data into cache files and then read them later, using Gson to serialize and deserialize these data.  
Project Address: https://github.com/westlinkin/CacheUtilsLibrary  

1. EasyDeviceInfo  
Android library to get device information in a super easy way.  
Project Address: https://github.com/nisrulz/easydeviceinfo 

## 3. Excellent projects  
Linux  
Project Address: https://github.com/torvalds/linux  
Android  
Project Address: https://android.googlesource.com/  
   
(1) ZXing  
ZXing ("zebra crossing") is an open-source, multi-format 1D/2D barcode image processing library implemented in Java, with ports to other languages.  
Project Address: https://github.com/zxing/zxing  
Demo Apk: https://play.google.com/store/apps/details?id=com.google.zxing.client.android   
   
(2) photup  
With photup you can share your photos to your Facebook profile, quicker than ever before.  
Project Address: https://github.com/chrisbanes/photup  
Demo Apk: https://play.google.com/store/apps/details?id=uk.co.senab.photup  
     
(3) github-android 
GitHub Android App  
Project Address: https://github.com/github/android  
Demo Apk: https://play.google.com/store/apps/details?id=com.github.mobile  
   
(4) Notes  
MIUI Notes
Project Address: https://github.com/MiCode/Notes  
Demo Apk: https://github.com/Trinea/TrineaDownload/blob/master/miui-note-demo.apk?raw=true  
   
(5) weicuiyuan  
Sina Weibo Android Client  
Project Address: https://github.com/qii/weiciyuan  
Demo Apk: https://play.google.com/store/apps/details?id=org.qii.weiciyuan  
   
(6) gnucash-android  
Gnucash for Android mobile companion application.  
Project Address: https://github.com/codinguser/gnucash-android  
Demo Apk: http://play.google.com/store/apps/details?id=org.gnucash.android  
   
(7) AntennaPod  
A podcast manager for Android  
Project Address: https://github.com/danieloeh/AntennaPod  
Demo Apk: https://play.google.com/store/apps/details?id=de.danoeh.antennapod  
   
(8) ChaseWhisplyProject  
An augmented reality attempt  
Project Address: https://github.com/tvbarthel/ChaseWhisplyProject  
Demo Apk: https://play.google.com/store/apps/details?id=fr.tvbarthel.games.chasewhisply  
   
(9) Tweet Lanes  
Tweet Lanes for Android  
Project Address: https://github.com/chrislacy/TweetLanes  
Demo Apk: https://play.google.com/store/apps/details?id=com.tweetlanes.android  

(10) Financius  
Android Expense Manager  
Project Address: https://github.com/mvarnagiris/Financius  
Demo Apk: https://play.google.com/store/apps/details?id=com.code44.finance  

(11) todo.txt-android  
Official Todo.txt Android app for managing your todo.txt file stored in Dropbox.  
Project Address: https://github.com/ginatrapani/todo.txt-android  
Demo Apk: https://play.google.com/store/apps/details?id=com.todotxt.todotxttouch  

(13) Muzei Live Wallpaper  
Muzei Live Wallpaper for Android  
Project Address: https://github.com/romannurik/muzei  
Demo Apk: https://play.google.com/store/apps/details?id=net.nurik.roman.muzei  

(14) Etar Calendar  
Etar is an OpenSource material designed calendar  
Project Address: https://github.com/xsoh/Etar-Calendar  
Demo Apk: https://play.google.com/store/apps/details?id=ws.xsoh.etar  
Renderings: ![Etar Calendar](https://raw.githubusercontent.com/xsoh/Etar-Calendar/materialdesign/assets/_pre_prod/publish/v1.0/animation.gif)  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>

## 4: Development and testing tools  
Android open source projects about development tools and testing tools.  <a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
#### 1. Development productivity tools  
1. Json2Java  
Automate processing Java classes to mirror json models.  
Project Address: https://github.com/jonfhancock/JsonToJava  
Online Demo: http://jsontojava.appspot.com/  

1. IntelliJ Plugin for Android Parcelable boilerplate code generation  
IntelliJ Plugin for Android Parcelable boilerplate code generation.  
Project Address: https://github.com/mcharmas/android-parcelable-intellij-plugin  
Renderings: ![Holo Colors Idea](https://github.com/mcharmas/android-parcelable-intellij-plugin/raw/master/screenshot.png)  
  
1. Android Holo Colors IntelliJ Plugin  
IntelliJ / Android Studio plugin for Android Holo Colors  
Project Address: https://github.com/jeromevdl/android-holo-colors-idea-plugin  
Renderings: ![Holo Colors Idea](https://raw.github.com/jeromevdl/android-holo-colors-idea-plugin/master/other/holocolorsidea.png)  

1. Android Drawable Factory  
A Java Application to create appropriate Drawable resources for your Android application  
Project Address: https://github.com/tizionario/AndroidDrawableFactory  
Renderings: ![Android Drawable Factory](https://github-camo.global.ssl.fastly.net/5c3844b345a9779296f996490070dab0bfc9dbf5/68747470733a2f2f646c2e64726f70626f7875736572636f6e74656e742e636f6d2f752f32363636343637352f416e64726f69644472617761626c65466163746f72792f312e706e67)  

1. SelectorChapek for Android  
Android Studio plugin which automatically generates drawable selectors from appropriately named resources.  
Project Address: https://github.com/inmite/android-selector-chapek  
   
1. Android Action Bar Style Generator  
Easily create a simple, attractive and seamless custom action bar style for your Android application  
Project Address: https://github.com/jgilfelt/android-actionbarstylegenerator  
Online Demo: http://jgilfelt.github.io/android-actionbarstylegenerator/  

1. ButterKnifeZelezny  
Android Studio plug-in for generating [ButterKnife](https://github.com/JakeWharton/butterknife) injections from selected layout XML.  
Project Address: https://github.com/inmite/android-butterknife-zelezny  

1. RoboCoP  
Pure Java code generation tool for generating a fully functional ContentProvider for Android.  
Project Address: https://github.com/mediarain/RoboCoP  

1. appiconsizes  
IOS and Android App Icon size generator  
Project Address: http://www.appiconsizes.com/  

1. Gradle Retrolambda Plugin  
This plugin will automatically build your java or android project with [Retrolambda](https://github.com/orfjackal/retrolambda), giving you lambda goodness on java 6 or 7. It relies on the wonderful retrolambda by Esko Luontola.  
Project Address: https://github.com/evant/gradle-retrolambda  

1. jsonschema2pojo  
Generates Java types from JSON Schema (or example JSON) and annotates those types for data-binding with Jackson 1.x or 2.x, Gson.  
Project Address: https://github.com/joelittlejohn/jsonschema2pojo  
Online Demo: http://www.jsonschema2pojo.org/  

<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 2. Develop self-test related  
1. Quality Tools for Android  
This is an Android sample app + tests that will be used to work on various project to increase the quality of the Android platform.  
Project Address: https://github.com/stephanenicolas/Quality-Tools-for-Android  

1. android-test-kit  
Google's Testing Tools For Android  
Project Address: https://code.google.com/p/android-test-kit/  
Document: https://code.google.com/p/android-test-kit/w/list  
  
1. robolectric  
Robolectric is a unit test framework that de-fangs the Android SDK so you can test-drive the development of your Android app.  
Project Address: https://github.com/robolectric/robolectric  
Demo Apk: https://github.com/robolectric/robolectricsample  
Document: http://robolectric.org/  

1. Android FEST  
A set of FEST assertion helpers geared toward testing Android.  
Project Address: https://github.com/square/fest-android  

1. BoundBox  
BoundBox provides an easy way to test an object by accessing all its fields, constructor and methods, public or not. BoundBox breaks encapsulation.  
Project Address: https://github.com/stephanenicolas/boundbox  

1. Hugo  
Annotation-triggered method call logging for your debug builds.  
Project Address: https://github.com/JakeWharton/hugo  
  
1. scalpel  
A surgical debugging tool to uncover the layers under your app.  
Project Address: https://github.com/JakeWharton/scalpel  
  
1. Android Screenshot library  
On-demand screenshots for your Android integration tests  
Project Address: https://github.com/rtyley/android-screenshot-lib  
  
1. sonar-android-lint-plugin  
Extension plugin for Android Lint in Sonar  
Project Address: https://github.com/SonarCommunity/sonar-android  
Document: http://docs.codehaus.org/display/SONAR/Android+Plugin  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 3. Testing tools  
1. Spoon  
Distributing instrumentation tests to all your Androids.  
Project Address: https://github.com/square/spoon    
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 4. Development and build environment  
1. Buck  
Buck is an Android build tool, is more powerful than ant.  
Project Address: https://github.com/facebook/buck  
   
1. Android Maven Plugin  
A plugin for Android application development with Apache Maven 3.1.1+ and the Android SDK.  
Project Address: https://github.com/jayway/maven-android-plugin  

1. umeng-muti-channel-build-tool  
Umeng packaing tools  
Project Address: https://github.com/umeng/umeng-muti-channel-build-tool  
   
1. Genymotion  
THE FASTER ANDROID EMULATOR  
Project Address: http://www.genymotion.com/  
  
1. gradle-mvn-push  
Helper to upload Gradle Android Artifacts to Maven repositories  
Project Address: https://github.com/chrisbanes/gradle-mvn-push  
Document: https://github.com/chrisbanes/gradle-mvn-push#usage    

1. Android Emulator Plugin for Jenkins  
Android Emulator plugin for Jenkins  
Project Address: https://github.com/jenkinsci/android-emulator-plugin  

1. Android Maven Plugin  
A tool to install components of the Android SDK to use with the Maven Android Plugin.  
Project Address: https://github.com/mosabua/maven-android-sdk-deployer  

1. SDK Manager Plugin  
Gradle plugin which downloads and manages your Android SDK.  
Project Address: https://github.com/JakeWharton/sdk-manager-plugin  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 5. Others  
1. ViewServer  
Local server for Android's HierarchyViewer  
Project Address: https://github.com/romainguy/ViewServer  
   
1. GridWichterle for Android  
This app will show grid overlay over whole system which helps you to verify your excellent app design.  
Project Address: https://github.com/inmite/android-grid-wichterle  
Demo Apk: https://play.google.com/store/apps/details?id=eu.inmite.android.gridwichterle  

1. Catlog  
Logcat-reading app for Android  
Project Address: https://github.com/nolanlawson/Catlog  
Online Demo: https://play.google.com/store/apps/details?id=com.nolanlawson.logcat  
   
1. PID Cat  
Colored logcat script which only shows log entries for a specific application package.  
Project Address: https://github.com/JakeWharton/pidcat  

1. ACRA  
ACRA is a library enabling Android Application to automatically post their crash reports to a GoogleDoc form. It is targetted to android applications developers to help them get data from their applications when they crash or behave erroneously.  
Project Address: https://github.com/ACRA/acra  
Document: https://github.com/ACRA/acra/wiki/BasicSetup  

1. Android Resource Navigator  
Chrome Extension providing enhanced resource navigation for GitHub hosted Android projects  
Project Address: https://github.com/jgilfelt/android-resource-navigator  
Online Demo: https://chrome.google.com/webstore/detail/android-resource-navigato/agoomkionjjbejegcejiefodgbckeebo?hl=en&gl=GB  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  
  
## 4. Outstanding individuals and groups  
#### 1. Individual  
1. JakeWharton  
Github Address: https://github.com/JakeWharton  
Masterpiece: ActionBarSherlock，Android-ViewPagerIndicator，Nine Old Androids，SwipeToDismissNOA，hugo，butterknife，Android-DirectionalViewPager, scalpel  
HomePage: http://jakewharton.com/  
   
1. Chris Banes  
Github Address: https://github.com/chrisbanes  
Masterpiece: ActionBar-PullToRefresh，PhotoView，Android-BitmapCache，Android-PullToRefresh  
HomePage: http://chris.banes.me/  
   
1. Koushik Dutta  
Github Address: https://github.com/koush  
Masterpiece: Superuser，AndroidAsync，UrlImageViewHelper，ion  
HomePage: http://koush.com/  
   
1. Simon Vig  
Github Address: https://github.com/SimonVT  
Masterpiece: android-menudrawer，MessageBar  
HomePage: http://simonvt.net/  
   
1. Manuel Peinado  
Github Address: https://github.com/ManuelPeinado  
Masterpiece: FadingActionBar，GlassActionBar，RefreshActionItem，QuickReturnHeader  
   
1. Emil Sj?lander  
Github Address: https://github.com/emilsjolander  
Masterpiece: StickyListHeaders，sprinkles，android-FlipView  
HomePage: http://emilsjolander.se/  
   
1. greenrobot  
Github Address: https://github.com/greenrobot  
Masterpiece: greenDAO，EventBus  
HomePage: http://greenrobot.de/  
   
1. Jeff Gilfelt  
Github Address: https://github.com/jgilfelt  
Masterpiece: android-mapviewballoons，android-viewbadger，android-actionbarstylegenerator，android-sqlite-asset-helper  
HomePage: http://jeffgilfelt.com  

1.  Romain Guy  
Github Address: https://github.com/romainguy  
Masterpiece: ViewServer  
HomePage: http://www.curious-creature.org/category/android/   
Other：http://www.flickr.com/photos/romainguy  

1. sephiroth74  
Github Address: https://github.com/sephiroth74  
Masterpiece: ImageViewZoom，HorizontalVariableListView，AndroidWheel，purePDF  
HomePage: http://www.sephiroth.it/   

1. Cyril Mottier  
Github Address: https://github.com/cyrilmottier  
Masterpiece: GreenDroid，Polaris  
HomePage: http://cyrilmottier.com/  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

#### 2. Group  
1. Square  
Github Address: https://github.com/square   
Masterpiece: okhttp, fest-android，android-times-square, picasso, dagger, spoon and so on
HomePage: http://square.github.io/  
   
1. Inmite s.r.o.  
Github Address: https://github.com/inmite  
Masterpiece: android-styled-dialogs，android-grid-wichterle，android-selector-chapek  
HomePage: http://www.inmite.eu/  
<a href="https://github.com/Trinea/android-open-project/edit/master/English%20Version/README.md#include" title="Back to directory" style="width:100%"><img src="http://farm4.staticflickr.com/3737/12167413134_edcff68e22_o.png" align="right"/></a>  

## License

    Copyright 2014 trinea.cn

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
